-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: AllTrue
-- ------------------------------------------------------
-- Server version	10.11.6-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Announcements`
--

DROP TABLE IF EXISTS `Announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Announcements` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Title` varchar(100) NOT NULL,
  `Content` text NOT NULL,
  `BranchID` int(11) DEFAULT NULL,
  `TargetStudentID` int(11) DEFAULT NULL,
  `IsActive` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Announcements`
--

LOCK TABLES `Announcements` WRITE;
/*!40000 ALTER TABLE `Announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `Announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ApiClient`
--

DROP TABLE IF EXISTS `ApiClient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ApiClient` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(64) NOT NULL,
  `ApiKeyHash` varchar(64) NOT NULL,
  `CampusID` int(11) NOT NULL,
  `Active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `apiclient_apikeyhash_unique` (`ApiKeyHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ApiClient`
--

LOCK TABLES `ApiClient` WRITE;
/*!40000 ALTER TABLE `ApiClient` DISABLE KEYS */;
/*!40000 ALTER TABLE `ApiClient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BaseData`
--

DROP TABLE IF EXISTS `BaseData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BaseData` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(32) NOT NULL,
  `Val` varchar(32) NOT NULL,
  `TypeID` int(11) DEFAULT NULL,
  `OrderID` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `basedata_name_val_unique` (`Name`,`Val`),
  UNIQUE KEY `basedata_name_val_typeid_unique` (`Name`,`Val`,`TypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BaseData`
--

LOCK TABLES `BaseData` WRITE;
/*!40000 ALTER TABLE `BaseData` DISABLE KEYS */;
/*!40000 ALTER TABLE `BaseData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Campus`
--

DROP TABLE IF EXISTS `Campus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Campus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `Current` int(11) NOT NULL DEFAULT 0,
  `LineNotifyID` varchar(128) NOT NULL,
  `Client_ID` varchar(32) NOT NULL,
  `Client_Secret` varchar(64) NOT NULL,
  `LIFFID` varchar(32) NOT NULL,
  `LIFF_URL` varchar(64) NOT NULL,
  `messaging_channel_token` text DEFAULT NULL,
  `messaging_channel_secret` varchar(64) DEFAULT NULL,
  `staff_line_group_id` varchar(64) DEFAULT NULL,
  `URL` varchar(64) NOT NULL,
  `Token` varchar(64) DEFAULT NULL,
  `TelegramToken` varchar(64) DEFAULT NULL,
  `TelegramChatID` varchar(32) DEFAULT NULL,
  `TelegramURL` varchar(64) NOT NULL,
  `TeachLIFFID` varchar(64) NOT NULL,
  `TeachLIFF_URL` varchar(64) NOT NULL,
  `SwipeWindowMinutes` int(11) NOT NULL DEFAULT 30,
  `code` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campus_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Campus`
--

LOCK TABLES `Campus` WRITE;
/*!40000 ALTER TABLE `Campus` DISABLE KEYS */;
INSERT INTO `Campus` VALUES
(1,'大安分校',0,'','','','','',NULL,NULL,NULL,'','gqGmhKzSF388VCcHftLe5OrDc2maHRfvnafhHbNKZYNWP5bCil5dhCxnpPSnu555',NULL,NULL,'','','',30,'daan'),
(2,'木柵分校',0,'','','','','',NULL,NULL,NULL,'','C0qVZRZlH581zfJYZxc6TUATGAPpIkq3zT5ytOcSYtP5pyk29jcH4KBwZPYyDlwV',NULL,NULL,'','','',30,'muzha'),
(3,'興隆分校',0,'','','','','',NULL,NULL,NULL,'','nMm3zC8BNVNBneCG1g518mqovVQK843uhfPSdQS49d6XzIlNTxC293gUS69qtlrn',NULL,NULL,'','','',30,'xinglong'),
(4,'新店分校',0,'','','','','',NULL,NULL,NULL,'','ZXlwBP5FSrRabzNHDApLu9XO8keA3mWFzsvRrKfBVjHvrz6IniMgCSk1ug9hVR15',NULL,NULL,'','','',30,'xindian'),
(5,'新竹分校',0,'','','','','',NULL,NULL,NULL,'','eQVbwTD756OpDPo7jDhMlt8W3TLgDgwS23pVjJELo7SygaK74yydbh9xTz9FKgWl',NULL,NULL,'','','',30,'hsinchu'),
(6,'天母分校',0,'','','','','',NULL,NULL,NULL,'','yf08XLB2I66g0O8ZhoQAVAUG1nDUxKBDrBvPwQmvUhK60083qGkfptO7UxrYxkyH',NULL,NULL,'','','',30,'tianmu'),
(7,'中壢分校',0,'','','','','',NULL,NULL,NULL,'','Wxq32OxAlNQJkrYlIEuwBmYauAVGr7k4IB2YBoA07aB7O2OaN8fEQ4F0cuYAZYIJ',NULL,NULL,'','','',30,'zhongli'),
(8,'桃園分校',0,'','','','','',NULL,NULL,NULL,'','lcErqcuxauSMCnaqaGWEw5wpqOuRAaBakjb6Jo6C2t5TlbFGB30pKCzBgU2KkcOk',NULL,NULL,'','','',30,'taoyuan'),
(9,'東湖分校',0,'','','','','',NULL,NULL,NULL,'','e9FHsUEHBbH4L0CmtxoPEblZV7kzYGxZqOCx7p6BeI4wufN0vnaqJFYnn9LKlNl5',NULL,NULL,'','','',30,'donghu'),
(10,'大直分校',0,'','','','','',NULL,NULL,NULL,'','LyEZ6pCPGbDRdmfqyxna9V3Y0wfVaeGFZRgIDze0PnoF8rA2iDpiutvbszqkeyV9',NULL,NULL,'','','',30,'dazhi'),
(11,'汐止分校',0,'','','','','',NULL,NULL,NULL,'','RX1r8YCEkxKnGRkjimGmVHq4OXOxgvbgiXPomIwaw4WDkpCwfiLRJsXpBxUOvtXA',NULL,NULL,'','','',30,'xizhi'),
(12,'內湖分校',0,'','','','','',NULL,NULL,NULL,'','9bS6plRN0iXClbnSrgJOQYiZabS9qE9IRbQmBHNpqeJpizU4LeU9m2teOXK9YWU2',NULL,NULL,'','','',30,'neihu'),
(13,'石牌分校',0,'','','','','',NULL,NULL,NULL,'','iRJommoNlwo9R30jDGWw7zpFgB1WOxxpEhfJHGcXcfosYZAcOyPmzxv8zGPCUc3H',NULL,NULL,'','','',30,'shipai'),
(14,'敦化分校',0,'','','','','',NULL,NULL,NULL,'','OdhCjppR1Y5m1cCftut78Dyt4NI6v9gHx6l1fjgglrY87btjSOeCOGbO34C6EVHp',NULL,NULL,'','','',30,'dunhua'),
(15,'蘆洲分校',0,'','','','','',NULL,NULL,NULL,'','04iAyMZN3FBoi4vXEGkC9tYrxR6a3ntdGHBBPFZX67QdMTSyGdmKobmOZBkE6a9C',NULL,NULL,'','','',30,'luzhou'),
(16,'大同分校',0,'','','','','',NULL,NULL,NULL,'','5fhilCei17LLcyoeV9kw9PMHsgzvN2857jImHeouvmWjEUEYqRCF6fN91ZowmeBR',NULL,NULL,'','','',30,'datong'),
(27,'Thadhaven分校',0,'','','','','',NULL,NULL,NULL,'',NULL,NULL,NULL,'','','',30,'branchlev'),
(28,'West Tracebury分校',0,'','','','','',NULL,NULL,NULL,'',NULL,NULL,NULL,'','','',30,'branchngu'),
(29,'Moenstad分校',0,'','','','','',NULL,NULL,NULL,'',NULL,NULL,NULL,'','','',30,'branchvlu'),
(30,'North Lesliechester分校',0,'','','','','',NULL,NULL,NULL,'',NULL,NULL,NULL,'','','',30,'branchwxd'),
(31,'Lemketown分校',0,'','','','','',NULL,NULL,NULL,'',NULL,NULL,NULL,'','','',30,'branchdns'),
(32,'Cyrilmouth分校',0,'','','','','',NULL,NULL,NULL,'',NULL,NULL,NULL,'','','',30,'branchyov');
/*!40000 ALTER TABLE `Campus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ClassSession`
--

DROP TABLE IF EXISTS `ClassSession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ClassSession` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `StudentClassID` bigint(20) NOT NULL,
  `SubjectID` bigint(20) DEFAULT NULL,
  `SessionDate` date NOT NULL,
  `StartTime` time NOT NULL,
  `EndTime` time NOT NULL,
  `Status` varchar(16) NOT NULL DEFAULT 'scheduled',
  `Note` varchar(255) NOT NULL DEFAULT '',
  `IsContractException` tinyint(1) NOT NULL DEFAULT 0,
  `session_charge` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `class_session_subject_id_idx` (`SubjectID`),
  KEY `classsession_iscontractexception_index` (`IsContractException`),
  KEY `cs_scid_sessiondate_idx` (`StudentClassID`,`SessionDate`),
  KEY `idx_cs_status` (`Status`)
) ENGINE=InnoDB AUTO_INCREMENT=975 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ClassSession`
--

LOCK TABLES `ClassSession` WRITE;
/*!40000 ALTER TABLE `ClassSession` DISABLE KEYS */;
/*!40000 ALTER TABLE `ClassSession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ImportJob`
--

DROP TABLE IF EXISTS `ImportJob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ImportJob` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Type` varchar(32) NOT NULL,
  `Status` varchar(16) NOT NULL DEFAULT 'pending',
  `FileName` varchar(255) NOT NULL,
  `Summary` varchar(255) NOT NULL DEFAULT '',
  `ErrorLog` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ImportJob`
--

LOCK TABLES `ImportJob` WRITE;
/*!40000 ALTER TABLE `ImportJob` DISABLE KEYS */;
/*!40000 ALTER TABLE `ImportJob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Invoice`
--

DROP TABLE IF EXISTS `Invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Invoice` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `StudentID` int(11) NOT NULL,
  `StudentClassID` bigint(20) DEFAULT NULL,
  `IssueDate` date NOT NULL,
  `DueDate` date DEFAULT NULL,
  `TotalAmount` int(11) NOT NULL,
  `PaidAmount` int(11) NOT NULL DEFAULT 0,
  `Status` varchar(16) NOT NULL DEFAULT 'unpaid',
  `Note` varchar(255) NOT NULL DEFAULT '',
  `reconciled_at` timestamp NULL DEFAULT NULL,
  `reconciled_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_inv_student_id` (`StudentID`),
  KEY `idx_inv_sc_id` (`StudentClassID`),
  KEY `idx_inv_status` (`Status`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Invoice`
--

LOCK TABLES `Invoice` WRITE;
/*!40000 ALTER TABLE `Invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `Invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InvoiceItem`
--

DROP TABLE IF EXISTS `InvoiceItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `InvoiceItem` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `InvoiceID` bigint(20) NOT NULL,
  `StudentClassID` bigint(20) unsigned DEFAULT NULL,
  `Description` varchar(255) NOT NULL,
  `Amount` int(11) NOT NULL,
  `PeriodStart` date DEFAULT NULL,
  `PeriodEnd` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoiceitem_studentclassid_index` (`StudentClassID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InvoiceItem`
--

LOCK TABLES `InvoiceItem` WRITE;
/*!40000 ALTER TABLE `InvoiceItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `InvoiceItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LearningRecord`
--

DROP TABLE IF EXISTS `LearningRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LearningRecord` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `StudentClassID` bigint(20) NOT NULL,
  `ClassSessionID` bigint(20) unsigned NOT NULL,
  `TeacherID` int(11) NOT NULL,
  `CreatedByUserID` bigint(20) unsigned DEFAULT NULL,
  `Content` text NOT NULL,
  `AttachmentUrl` varchar(255) DEFAULT NULL,
  `Status` varchar(32) NOT NULL DEFAULT 'pending',
  `ApprovedBy` int(11) DEFAULT NULL,
  `ApprovedAt` datetime DEFAULT NULL,
  `SessionDeducted` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `ReviewNote` varchar(255) DEFAULT NULL,
  `Subject` varchar(32) DEFAULT NULL,
  `SessionDate` date DEFAULT NULL,
  `StartTime` time DEFAULT NULL,
  `EndTime` time DEFAULT NULL,
  `HomeworkStatus` varchar(16) DEFAULT NULL,
  `QuizScore` varchar(32) DEFAULT NULL,
  `Progress` text DEFAULT NULL,
  `NextHomework` text DEFAULT NULL,
  `NextWeekTestScope` text DEFAULT NULL,
  `Performance` varchar(16) DEFAULT NULL,
  `Comment` text DEFAULT NULL,
  `VoidedAt` timestamp NULL DEFAULT NULL,
  `VoidedByUserID` bigint(20) unsigned DEFAULT NULL,
  `VoidReason` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `learningrecord_classsessionid_unique` (`ClassSessionID`),
  KEY `lr_status_sessiondate_idx` (`Status`,`SessionDate`),
  KEY `lr_teachid_status_idx` (`TeacherID`,`Status`),
  KEY `lr_scid_sessiondate_idx` (`StudentClassID`,`SessionDate`),
  KEY `lr_payroll_teacher_status_date` (`TeacherID`,`Status`,`SessionDate`),
  CONSTRAINT `learningrecord_classsession_fk` FOREIGN KEY (`ClassSessionID`) REFERENCES `ClassSession` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LearningRecord`
--

LOCK TABLES `LearningRecord` WRITE;
/*!40000 ALTER TABLE `LearningRecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `LearningRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NotificationReads`
--

DROP TABLE IF EXISTS `NotificationReads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NotificationReads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `NotificationID` bigint(20) unsigned NOT NULL,
  `UserID` int(10) unsigned NOT NULL,
  `ReadAt` datetime DEFAULT NULL,
  `ArchivedAt` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notification_reads_unique` (`NotificationID`,`UserID`),
  KEY `notificationreads_userid_readat_index` (`UserID`,`ReadAt`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NotificationReads`
--

LOCK TABLES `NotificationReads` WRITE;
/*!40000 ALTER TABLE `NotificationReads` DISABLE KEYS */;
/*!40000 ALTER TABLE `NotificationReads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notifications`
--

DROP TABLE IF EXISTS `Notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `CampusID` int(11) DEFAULT NULL,
  `Type` varchar(32) NOT NULL,
  `Severity` varchar(16) NOT NULL DEFAULT 'info',
  `Title` varchar(191) NOT NULL,
  `Body` text DEFAULT NULL,
  `SourceType` varchar(64) DEFAULT NULL,
  `SourceID` varchar(64) DEFAULT NULL,
  `SourceKey` varchar(191) NOT NULL,
  `Payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`Payload`)),
  `OccurredAt` datetime DEFAULT NULL,
  `ResolvedAt` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notifications_sourcekey_unique` (`SourceKey`),
  KEY `notifications_campusid_type_index` (`CampusID`,`Type`),
  KEY `notifications_resolvedat_occurredat_index` (`ResolvedAt`,`OccurredAt`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notifications`
--

LOCK TABLES `Notifications` WRITE;
/*!40000 ALTER TABLE `Notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ParentSession`
--

DROP TABLE IF EXISTS `ParentSession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ParentSession` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `StudentID` int(11) NOT NULL,
  `TokenHash` varchar(64) NOT NULL,
  `ExpiresAt` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parentsession_tokenhash_index` (`TokenHash`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ParentSession`
--

LOCK TABLES `ParentSession` WRITE;
/*!40000 ALTER TABLE `ParentSession` DISABLE KEYS */;
/*!40000 ALTER TABLE `ParentSession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Payment`
--

DROP TABLE IF EXISTS `Payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Payment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `InvoiceID` bigint(20) NOT NULL,
  `Amount` int(11) NOT NULL,
  `PaidAt` datetime NOT NULL,
  `Method` varchar(32) NOT NULL DEFAULT 'cash',
  `Note` varchar(255) NOT NULL DEFAULT '',
  `receipt_url` varchar(255) DEFAULT NULL,
  `payment_report_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pay_invoice_id` (`InvoiceID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Payment`
--

LOCK TABLES `Payment` WRITE;
/*!40000 ALTER TABLE `Payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `Payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PendingSwipe`
--

DROP TABLE IF EXISTS `PendingSwipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PendingSwipe` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `RFID` varchar(32) NOT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `CampusID` int(11) DEFAULT NULL,
  `SwipeAt` datetime NOT NULL,
  `Reason` varchar(64) NOT NULL,
  `Payload` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PendingSwipe`
--

LOCK TABLES `PendingSwipe` WRITE;
/*!40000 ALTER TABLE `PendingSwipe` DISABLE KEYS */;
/*!40000 ALTER TABLE `PendingSwipe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Student`
--

DROP TABLE IF EXISTS `Student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Student` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `CampusID` int(11) NOT NULL,
  `ClassID` int(11) NOT NULL,
  `SchoolName` varchar(32) DEFAULT NULL,
  `RFID` varchar(16) DEFAULT NULL,
  `LineID` varchar(64) DEFAULT NULL,
  `TelegramID` varchar(32) NOT NULL DEFAULT '',
  `TelegramID1` varchar(32) DEFAULT NULL,
  `TelegramID2` varchar(32) DEFAULT NULL,
  `enable` int(11) NOT NULL DEFAULT 1,
  `MDT` datetime NOT NULL DEFAULT current_timestamp(),
  `Notify_Token` varchar(64) NOT NULL DEFAULT '',
  `Phone` varchar(20) DEFAULT NULL,
  `parent_name` varchar(64) DEFAULT NULL,
  `parent_phone` varchar(20) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` varchar(32) DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `student_rfid_unique` (`RFID`),
  KEY `idx_student_campus_name` (`CampusID`,`name`),
  KEY `idx_student_campus_status` (`CampusID`,`status`),
  KEY `idx_student_rfid` (`RFID`)
) ENGINE=InnoDB AUTO_INCREMENT=612 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Student`
--

LOCK TABLES `Student` WRITE;
/*!40000 ALTER TABLE `Student` DISABLE KEYS */;
INSERT INTO `Student` VALUES
(453,'Test Student',32,7,'Test Junior High',NULL,NULL,'',NULL,NULL,1,'2026-04-22 00:42:30','','0911222333',NULL,NULL,NULL,'active');
/*!40000 ALTER TABLE `Student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `StudentClass`
--

DROP TABLE IF EXISTS `StudentClass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `StudentClass` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `StudentID` int(11) NOT NULL,
  `GradeID` int(11) NOT NULL,
  `SubjectID` int(11) NOT NULL,
  `TeacherID` int(11) NOT NULL,
  `by1` int(11) NOT NULL,
  `Period` int(11) NOT NULL DEFAULT 4,
  `StartDate` datetime NOT NULL,
  `EndDate` datetime DEFAULT NULL,
  `week` int(11) DEFAULT NULL,
  `time` time DEFAULT NULL,
  `week1` int(11) DEFAULT NULL,
  `time1` time DEFAULT NULL,
  `week2` int(11) DEFAULT NULL,
  `time2` time DEFAULT NULL,
  `week3` int(11) DEFAULT NULL,
  `time3` time DEFAULT NULL,
  `week4` int(11) DEFAULT NULL,
  `time4` time DEFAULT NULL,
  `week5` int(11) DEFAULT NULL,
  `time5` time DEFAULT NULL,
  `week6` int(11) DEFAULT NULL,
  `time6` time DEFAULT NULL,
  `TotalHours` int(11) NOT NULL,
  `Memo` varchar(512) DEFAULT NULL,
  `Charge` int(11) DEFAULT NULL,
  `Pay` int(11) DEFAULT NULL,
  `PayDate` date DEFAULT NULL,
  `Paid` int(11) NOT NULL DEFAULT 0,
  `Disconunt` int(11) DEFAULT NULL,
  `Rate` double(8,2) DEFAULT NULL,
  `rate_unit` varchar(16) NOT NULL DEFAULT 'session',
  `PackageID` bigint(20) unsigned DEFAULT NULL,
  `PackageTotalSessions` int(10) unsigned DEFAULT NULL,
  `PackageName` varchar(128) DEFAULT NULL,
  `LearnTimeID` int(11) DEFAULT NULL,
  `RoomID` varchar(32) NOT NULL,
  `room_id` bigint(20) unsigned DEFAULT NULL,
  `settlement_day` tinyint(3) unsigned DEFAULT NULL,
  `monthly_sessions` int(10) unsigned DEFAULT NULL,
  `MDate` datetime NOT NULL DEFAULT current_timestamp(),
  `Stop` tinyint(1) NOT NULL DEFAULT 0,
  `closed_reason` varchar(20) DEFAULT NULL,
  `ScheduleMode` varchar(16) NOT NULL DEFAULT 'date',
  `SessionCount` int(11) DEFAULT NULL,
  `SessionDuration` int(11) DEFAULT NULL,
  `duration1` int(11) DEFAULT NULL,
  `duration2` int(11) DEFAULT NULL,
  `duration3` int(11) DEFAULT NULL,
  `duration4` int(11) DEFAULT NULL,
  `duration5` int(11) DEFAULT NULL,
  `duration6` int(11) DEFAULT NULL,
  `RemainingSessions` int(11) DEFAULT NULL,
  `ClassType` varchar(32) NOT NULL DEFAULT 'regular',
  `UsedSessions` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `studentclass_room_id_foreign` (`room_id`),
  KEY `idx_sc_package_id` (`PackageID`),
  KEY `idx_sc_student_id` (`StudentID`),
  KEY `idx_sc_teacher_id` (`TeacherID`),
  KEY `idx_sc_stop_student` (`Stop`,`StudentID`),
  CONSTRAINT `studentclass_room_id_foreign` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=638 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `StudentClass`
--

LOCK TABLES `StudentClass` WRITE;
/*!40000 ALTER TABLE `StudentClass` DISABLE KEYS */;
/*!40000 ALTER TABLE `StudentClass` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `StudentSingIn`
--

DROP TABLE IF EXISTS `StudentSingIn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `StudentSingIn` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `StudentClassID` bigint(20) DEFAULT NULL,
  `StudentID` int(11) NOT NULL,
  `TeacherID` int(11) DEFAULT NULL,
  `RecordedByUserID` bigint(20) unsigned DEFAULT NULL,
  `GradeID` int(11) DEFAULT NULL,
  `SubjectID` int(11) DEFAULT NULL,
  `Get1byID` int(11) DEFAULT NULL,
  `Hours` int(11) DEFAULT NULL,
  `Memo` varchar(512) DEFAULT NULL,
  `SignInDT` datetime NOT NULL,
  `SignOutDT` datetime DEFAULT NULL,
  `MDT` datetime NOT NULL DEFAULT current_timestamp(),
  `ClassSessionID` bigint(20) DEFAULT NULL,
  `Status` varchar(16) NOT NULL DEFAULT 'present',
  `SessionDeducted` tinyint(1) NOT NULL DEFAULT 0,
  `VoidedAt` timestamp NULL DEFAULT NULL,
  `VoidedByUserID` bigint(20) unsigned DEFAULT NULL,
  `VoidReason` varchar(255) DEFAULT NULL,
  `PersonType` varchar(16) NOT NULL DEFAULT 'student',
  `CampusID` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `studentsingin_classsessionid_unique` (`ClassSessionID`),
  KEY `idx_ssi_student_id` (`StudentID`),
  KEY `idx_ssi_sc_id` (`StudentClassID`),
  KEY `idx_ssi_signindt` (`SignInDT`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `StudentSingIn`
--

LOCK TABLES `StudentSingIn` WRITE;
/*!40000 ALTER TABLE `StudentSingIn` DISABLE KEYS */;
/*!40000 ALTER TABLE `StudentSingIn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Subject`
--

DROP TABLE IF EXISTS `Subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Subject` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `School_id` int(11) NOT NULL,
  `Grade_no` int(11) NOT NULL,
  `Subject_Name` varchar(16) NOT NULL,
  `CampusID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject_campusid_index` (`CampusID`)
) ENGINE=InnoDB AUTO_INCREMENT=1560 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Subject`
--

LOCK TABLES `Subject` WRITE;
/*!40000 ALTER TABLE `Subject` DISABLE KEYS */;
INSERT INTO `Subject` VALUES
(1516,1,0,'Chinese',NULL),
(1517,1,0,'English',NULL),
(1518,1,0,'Math',NULL),
(1519,1,0,'Physics',NULL),
(1520,1,0,'Chemistry',NULL),
(1521,1,0,'Science',NULL),
(1522,1,0,'Biology',NULL),
(1523,1,0,'Social',NULL);
/*!40000 ALTER TABLE `Subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Teacher`
--

DROP TABLE IF EXISTS `Teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Teacher` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CampusID` int(11) NOT NULL,
  `T_Name` varchar(32) NOT NULL,
  `Phone` varchar(12) DEFAULT NULL,
  `RFID` varchar(16) DEFAULT NULL,
  `LineID` varchar(64) DEFAULT NULL,
  `TelegramID` varchar(32) NOT NULL DEFAULT '',
  `TelegramID1` varchar(32) DEFAULT NULL,
  `TelegramID2` varchar(32) DEFAULT NULL,
  `Notify_Token` varchar(64) DEFAULT NULL,
  `Enable` int(11) NOT NULL DEFAULT 1,
  `MDT` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `teacher_rfid_unique` (`RFID`)
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Teacher`
--

LOCK TABLES `Teacher` WRITE;
/*!40000 ALTER TABLE `Teacher` DISABLE KEYS */;
/*!40000 ALTER TABLE `Teacher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TeacherSingIn`
--

DROP TABLE IF EXISTS `TeacherSingIn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TeacherSingIn` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `TeacherID` int(11) NOT NULL,
  `CampusID` int(11) NOT NULL,
  `SignInDT` datetime NOT NULL,
  `SignOutDT` datetime DEFAULT NULL,
  `MDT` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TeacherSingIn`
--

LOCK TABLES `TeacherSingIn` WRITE;
/*!40000 ALTER TABLE `TeacherSingIn` DISABLE KEYS */;
/*!40000 ALTER TABLE `TeacherSingIn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TempRfid`
--

DROP TABLE IF EXISTS `TempRfid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TempRfid` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CampusID` int(10) unsigned NOT NULL,
  `RFID` varchar(32) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `temprfid_campusid_unique` (`CampusID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TempRfid`
--

LOCK TABLES `TempRfid` WRITE;
/*!40000 ALTER TABLE `TempRfid` DISABLE KEYS */;
/*!40000 ALTER TABLE `TempRfid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `LoginName` varchar(64) NOT NULL,
  `Name` varchar(32) NOT NULL,
  `PSW` varchar(255) DEFAULT NULL,
  `type` char(1) NOT NULL DEFAULT 'U',
  `status` varchar(32) DEFAULT 'active',
  `employment_type` varchar(32) DEFAULT 'full_time',
  `phone` varchar(32) DEFAULT NULL,
  `AvatarUrl` varchar(255) DEFAULT NULL,
  `TeachingSessionCount` int(10) unsigned NOT NULL DEFAULT 0,
  `MustChangePassword` tinyint(1) NOT NULL DEFAULT 0,
  `PasswordChangedAt` timestamp NULL DEFAULT NULL,
  `PasswordSetByUserID` bigint(20) unsigned DEFAULT NULL,
  `bug_inbox_last_seen_at` timestamp NULL DEFAULT NULL,
  `bug_inbox_last_seen_bug_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_loginname_type_unique` (`LoginName`,`type`),
  KEY `user_employment_type_idx` (`employment_type`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=1002 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES
(703,'stamm.garret@example.org','Hoyt Hermiston','$2y$04$NrOlMPdKk36vnbjcBGAQg.0PcbhwIKXtATGGcONM684zXHdjA.QcW','S','active','full_time','903835921',NULL,0,0,NULL,NULL,NULL,NULL),
(705,'pending.director@example.com','Pending Director','$2y$04$VdcyDN3rRzXPe39jtTuFX.KtCKHA8Q9ZRehXmLQI3ml99ezbaweLW','U','active','full_time',NULL,NULL,0,0,NULL,NULL,NULL,NULL),
(706,'deckow.rhea@example.org','Annamarie Gaylord','$2y$04$TPBJafo5XmFXnQfJ/ialfuxVvaXXJay9a..nmTpp7Adp6BF/Rcija','S','active','full_time','945131185',NULL,0,0,NULL,NULL,NULL,NULL),
(707,'approve.me@example.com','Dr. Marielle Gerhold','$2y$04$smCvFHm3ufHzYkrORIoVFugMdlLwmYQR13zYzGuY8xIllv9GiYFmC','D','active','full_time','938582924',NULL,0,0,NULL,NULL,NULL,NULL),
(708,'conrad11@example.com','Phoebe Lueilwitz','$2y$04$bFRV/5iVO6Z09as6my4H/u4XBPMgqbY/itMlxYTEbyaqUNPuQZhSu','S','active','full_time','976245988',NULL,0,0,NULL,NULL,NULL,NULL),
(709,'teacher.pending@example.com','Pending Teacher','$2y$04$sR6OvWOpvvoqIPdO0tmtO.a1i6U6h8ZY5yaecK6FeycgnEsHr4QSS','T','pending','full_time','947047813',NULL,0,0,NULL,NULL,NULL,NULL),
(710,'director.pending2@example.com','Pending Director Two','$2y$04$A1UlpHefnYTPTxB7fMJkn.qCWEYgNwpNimIC3m/jRTG7BIhCfJE1K','U','active','full_time','902548490',NULL,0,0,NULL,NULL,NULL,NULL),
(711,'frami.eldridge@example.net','Kayley Hermann','$2y$04$.5JTF9hUilcl9WlQnlY0we96f9Yt9wEXw07wy6djU2PQpjxe/0JGa','S','active','full_time','986228545',NULL,0,0,NULL,NULL,NULL,NULL),
(713,'xkeeling@example.net','Isabell Borer','$2y$04$UVxmIEw8gRUsq26zSowkke5cZ9l/fQxHA4wbFBCww8XmUOATQMehS','D','active','full_time','980315698',NULL,0,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserCampus`
--

DROP TABLE IF EXISTS `UserCampus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserCampus` (
  `CampusID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Admin` int(11) NOT NULL DEFAULT 0,
  `Approved` tinyint(1) NOT NULL DEFAULT 1,
  `RFID` varchar(32) DEFAULT NULL,
  KEY `idx_uc_user_id` (`UserID`),
  KEY `idx_uc_campus_approved` (`CampusID`,`Approved`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserCampus`
--

LOCK TABLES `UserCampus` WRITE;
/*!40000 ALTER TABLE `UserCampus` DISABLE KEYS */;
INSERT INTO `UserCampus` VALUES
(28,705,0,0,NULL),
(29,707,0,1,NULL),
(30,709,0,0,NULL),
(30,710,0,0,NULL),
(32,713,1,1,NULL);
/*!40000 ALTER TABLE `UserCampus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_tokens`
--

DROP TABLE IF EXISTS `auth_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(64) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_tokens_token_unique` (`token`),
  KEY `auth_tokens_user_id_index` (`user_id`),
  KEY `auth_tokens_token_index` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=612 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_tokens`
--

LOCK TABLES `auth_tokens` WRITE;
/*!40000 ALTER TABLE `auth_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bug_report_attachments`
--

DROP TABLE IF EXISTS `bug_report_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bug_report_attachments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bug_report_id` bigint(20) unsigned NOT NULL,
  `stored_path` varchar(500) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `mime_type` varchar(120) DEFAULT NULL,
  `size` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `bug_report_attachments_bug_report_id_index` (`bug_report_id`),
  CONSTRAINT `bug_report_attachments_bug_report_id_foreign` FOREIGN KEY (`bug_report_id`) REFERENCES `bug_reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bug_report_attachments`
--

LOCK TABLES `bug_report_attachments` WRITE;
/*!40000 ALTER TABLE `bug_report_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `bug_report_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bug_report_comments`
--

DROP TABLE IF EXISTS `bug_report_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bug_report_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bug_report_id` bigint(20) unsigned NOT NULL,
  `author_user_id` bigint(20) unsigned NOT NULL,
  `body` text NOT NULL,
  `is_internal_note` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `bug_report_comments_bug_report_id_id_index` (`bug_report_id`,`id`),
  CONSTRAINT `bug_report_comments_bug_report_id_foreign` FOREIGN KEY (`bug_report_id`) REFERENCES `bug_reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bug_report_comments`
--

LOCK TABLES `bug_report_comments` WRITE;
/*!40000 ALTER TABLE `bug_report_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `bug_report_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bug_report_status_logs`
--

DROP TABLE IF EXISTS `bug_report_status_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bug_report_status_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `bug_report_id` bigint(20) unsigned NOT NULL,
  `changed_by` bigint(20) unsigned NOT NULL,
  `from_status` varchar(20) NOT NULL,
  `to_status` varchar(20) NOT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `bug_report_status_logs_bug_report_id_created_at_index` (`bug_report_id`,`created_at`),
  CONSTRAINT `bug_report_status_logs_bug_report_id_foreign` FOREIGN KEY (`bug_report_id`) REFERENCES `bug_reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bug_report_status_logs`
--

LOCK TABLES `bug_report_status_logs` WRITE;
/*!40000 ALTER TABLE `bug_report_status_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `bug_report_status_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bug_report_user_reads`
--

DROP TABLE IF EXISTS `bug_report_user_reads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bug_report_user_reads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `bug_report_id` bigint(20) unsigned NOT NULL,
  `read_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `bug_report_user_reads_user_id_bug_report_id_unique` (`user_id`,`bug_report_id`),
  KEY `bug_report_user_reads_bug_report_id_index` (`bug_report_id`),
  CONSTRAINT `bug_report_user_reads_bug_report_id_foreign` FOREIGN KEY (`bug_report_id`) REFERENCES `bug_reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bug_report_user_reads`
--

LOCK TABLES `bug_report_user_reads` WRITE;
/*!40000 ALTER TABLE `bug_report_user_reads` DISABLE KEYS */;
/*!40000 ALTER TABLE `bug_report_user_reads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bug_reports`
--

DROP TABLE IF EXISTS `bug_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bug_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `CampusID` int(10) unsigned NOT NULL,
  `reporter_user_id` bigint(20) unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `severity` enum('low','medium','high','critical') NOT NULL DEFAULT 'medium',
  `status` enum('new','triaged','in_progress','resolved','closed') NOT NULL DEFAULT 'new',
  `page_key` varchar(50) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `client_info` text DEFAULT NULL,
  `assigned_to` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bug_reports_campusid_status_severity_created_at_index` (`CampusID`,`status`,`severity`,`created_at`),
  KEY `bug_reports_reporter_user_id_index` (`reporter_user_id`),
  KEY `idx_bugs_campus_status_created` (`CampusID`,`status`,`created_at`),
  KEY `idx_bugs_campus_severity_created` (`CampusID`,`severity`,`created_at`),
  KEY `idx_bugs_reporter_created` (`reporter_user_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bug_reports`
--

LOCK TABLES `bug_reports` WRITE;
/*!40000 ALTER TABLE `bug_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `bug_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `thread_id` bigint(20) unsigned NOT NULL,
  `sender_user_id` bigint(20) unsigned NOT NULL,
  `sender_name_snapshot` varchar(100) NOT NULL,
  `body` text NOT NULL,
  `message_type` varchar(20) NOT NULL DEFAULT 'text',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `media_url` varchar(500) DEFAULT NULL,
  `media_type` varchar(50) DEFAULT NULL,
  `media_name` varchar(255) DEFAULT NULL,
  `reply_to_message_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chat_messages_thread_id_id_index` (`thread_id`,`id`),
  KEY `chat_messages_reply_to_message_id_index` (`reply_to_message_id`),
  KEY `chat_messages_deleted_at_index` (`deleted_at`),
  CONSTRAINT `chat_messages_thread_id_foreign` FOREIGN KEY (`thread_id`) REFERENCES `chat_threads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_messages`
--

LOCK TABLES `chat_messages` WRITE;
/*!40000 ALTER TABLE `chat_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_thread_members`
--

DROP TABLE IF EXISTS `chat_thread_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_thread_members` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `thread_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `role` enum('owner','member') NOT NULL DEFAULT 'member',
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `left_at` timestamp NULL DEFAULT NULL,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `last_read_message_id` bigint(20) unsigned DEFAULT NULL,
  `last_read_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `chat_thread_members_thread_id_user_id_unique` (`thread_id`,`user_id`),
  KEY `chat_thread_members_user_id_index` (`user_id`),
  CONSTRAINT `chat_thread_members_thread_id_foreign` FOREIGN KEY (`thread_id`) REFERENCES `chat_threads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_thread_members`
--

LOCK TABLES `chat_thread_members` WRITE;
/*!40000 ALTER TABLE `chat_thread_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_thread_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_threads`
--

DROP TABLE IF EXISTS `chat_threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_threads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `CampusID` int(10) unsigned NOT NULL,
  `type` enum('dm','group') NOT NULL DEFAULT 'dm',
  `name` varchar(100) DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `last_message_id` bigint(20) unsigned DEFAULT NULL,
  `last_message_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `chat_threads_campusid_last_message_at_index` (`CampusID`,`last_message_at`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_threads`
--

LOCK TABLES `chat_threads` WRITE;
/*!40000 ALTER TABLE `chat_threads` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_threads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_packages`
--

DROP TABLE IF EXISTS `course_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `campus_id` bigint(20) unsigned NOT NULL,
  `name` varchar(128) NOT NULL,
  `total_sessions` int(10) unsigned NOT NULL,
  `remaining_sessions` int(11) NOT NULL DEFAULT 0,
  `used_sessions` int(10) unsigned NOT NULL DEFAULT 0,
  `rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `rate_unit` varchar(16) NOT NULL DEFAULT 'session',
  `class_type` varchar(32) NOT NULL DEFAULT 'one_on_one',
  `billing_mode` varchar(16) NOT NULL DEFAULT 'count',
  `settlement_day` tinyint(3) unsigned DEFAULT NULL,
  `paid` tinyint(1) NOT NULL DEFAULT 0,
  `paid_at` date DEFAULT NULL,
  `stop` tinyint(1) NOT NULL DEFAULT 0,
  `closed_reason` varchar(32) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cp_student` (`student_id`),
  KEY `idx_cp_campus` (`campus_id`),
  KEY `idx_cp_campus_stop` (`campus_id`,`stop`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_packages`
--

LOCK TABLES `course_packages` WRITE;
/*!40000 ALTER TABLE `course_packages` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `learning_record_teacher_changes`
--

DROP TABLE IF EXISTS `learning_record_teacher_changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `learning_record_teacher_changes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `learning_record_id` bigint(20) unsigned NOT NULL,
  `old_teacher_id` int(10) unsigned DEFAULT NULL,
  `new_teacher_id` int(10) unsigned NOT NULL,
  `changed_by` int(10) unsigned NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lr_teacher_changes_record_created_idx` (`learning_record_id`,`created_at`),
  KEY `lr_teacher_changes_new_teacher_idx` (`new_teacher_id`),
  KEY `lr_teacher_changes_changed_by_idx` (`changed_by`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `learning_record_teacher_changes`
--

LOCK TABLES `learning_record_teacher_changes` WRITE;
/*!40000 ALTER TABLE `learning_record_teacher_changes` DISABLE KEYS */;
/*!40000 ALTER TABLE `learning_record_teacher_changes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'2019_12_14_000001_create_personal_access_tokens_table',1),
(2,'2026_02_07_000001_create_basedata_table',1),
(3,'2026_02_07_000002_create_campus_table',1),
(4,'2026_02_07_000003_create_students_table',1),
(5,'2026_02_07_000004_create_student_classes_table',1),
(6,'2026_02_07_000005_create_teachers_table',1),
(7,'2026_02_07_000006_create_subjects_table',1),
(8,'2026_02_07_000007_create_users_table',1),
(9,'2026_02_07_000008_create_user_campus_table',1),
(10,'2026_02_07_000009_create_class_sessions_table',1),
(11,'2026_02_07_000010_create_invoices_table',1),
(12,'2026_02_07_000011_create_invoice_items_table',1),
(13,'2026_02_07_000012_create_payments_table',1),
(14,'2026_02_07_000013_create_import_jobs_table',1),
(15,'2026_02_07_000014_create_student_sign_in_table',1),
(16,'2026_02_07_000015_add_remaining_sessions_to_student_class_table',1),
(17,'2026_02_07_000016_create_learning_records_table',1),
(18,'2026_02_07_000017_add_review_note_to_learning_records_table',1),
(19,'2026_02_07_000018_add_phone_to_student_table',1),
(20,'2026_02_07_000019_create_parent_sessions_table',1),
(21,'2026_02_07_000020_add_class_type_to_student_class_table',1),
(22,'2026_02_07_000021_add_swipe_window_to_campus_table',1),
(23,'2026_02_07_000022_create_pending_swipes_table',1),
(24,'2026_02_07_000023_create_api_clients_table',1),
(25,'2026_02_13_000001_create_auth_tokens_table',1),
(26,'2026_02_13_000005_add_fields_to_learning_records_table',1),
(27,'2026_02_13_000006_create_teacher_monthly_stats_table',1),
(28,'2026_02_13_000007_add_used_sessions_to_student_class_table',1),
(29,'2026_02_13_100001_update_attendance_for_simplified_swipe',1),
(30,'2026_02_14_000001_add_security_improvements',1),
(31,'2026_02_14_100001_add_approved_to_user_campus',1),
(32,'2026_02_14_100001_add_code_to_campus_table',1),
(33,'2026_02_14_100002_fix_ghost_users',1),
(34,'2026_02_25_000001_expand_psw_column_for_mysql',1),
(35,'2026_02_25_000002_create_teacher_sing_in_table',1),
(36,'2026_02_25_000003_add_missing_columns_to_student_sing_in',1),
(37,'2026_02_25_000004_add_campus_to_teacher_sing_in',1),
(38,'2026_02_25_000005_add_mdt_to_teacher_sing_in',1),
(39,'2026_02_25_000006_create_temp_rfid_table',1),
(40,'2026_02_25_100001_seed_all_campuses_for_director_register',1),
(41,'2026_02_25_100002_fill_campus_code_null',1),
(42,'2026_02_26_000000_create_announcements_table',1),
(43,'2026_02_26_000001_add_created_by_and_teacher_kpi',1),
(44,'2026_02_26_000002_learning_record_text_fields',1),
(45,'2026_02_26_000003_seed_campus_tokens_for_swipe_rfid',1),
(46,'2026_02_26_100001_ensure_four_branches_only',1),
(47,'2026_03_02_000001_add_session_deducted_to_student_sing_in',1),
(48,'2026_03_03_000001_create_rooms_table',1),
(49,'2026_03_04_000001_add_memo_and_is_active_to_rooms_table',1),
(50,'2026_03_04_000002_add_room_settlement_to_student_class_table',1),
(51,'2026_03_04_100001_create_teacher_subjects_table',1),
(52,'2026_03_05_000001_add_status_to_user_table',1),
(53,'2026_03_13_000001_add_parent_fields_to_student_table',1),
(54,'2026_03_13_000002_create_notifications_table',1),
(55,'2026_03_13_000003_create_notification_reads_table',1),
(56,'2026_03_13_000004_adjust_user_loginname_unique_by_role',1),
(57,'2026_03_13_000005_create_password_reset_requests_table',1),
(58,'2026_03_13_000006_add_avatar_url_to_user_table',1),
(59,'2026_03_13_000007_create_user_notification_preferences_table',1),
(60,'2026_03_13_000008_create_user_login_activities_table',1),
(61,'2026_03_13_000009_change_user_phone_to_string',1),
(62,'2026_03_13_000010_add_password_change_flags_to_user_table',1),
(63,'2026_03_13_000011_add_donghu_dazhi_campuses',1),
(64,'2026_03_13_000012_add_xizhi_neihu_campuses',1),
(65,'2026_03_13_000013_create_schedules_table',1),
(66,'2026_03_13_000014_add_session_deducted_to_learning_records_table',1),
(67,'2026_03_15_000015_enforce_learning_record_class_session_fk',1),
(68,'2026_03_19_000016_add_recorded_by_user_id_to_student_sing_in',1),
(69,'2026_03_19_000016_create_learning_record_teacher_changes_table',1),
(70,'2026_04_03_100000_add_rfid_to_user_campus_table',1),
(71,'2026_04_08_000001_add_void_fields_and_create_deduction_ledger',1),
(72,'2026_04_08_000002_add_student_class_id_to_invoice_item',1),
(73,'2026_04_09_000001_create_system_settings_table',1),
(74,'2026_04_09_000002_add_messaging_fields_to_campus',1),
(75,'2026_04_09_000003_create_teacher_subject_levels_table',1),
(76,'2026_04_10_000001_add_per_day_duration_to_student_class',1),
(77,'2026_04_10_000002_normalize_natural_subject_to_science_mix',1),
(78,'2026_04_10_230000_widen_learning_record_status_column',1),
(79,'2026_04_11_000001_create_chat_tables',1),
(80,'2026_04_11_000002_create_bug_report_tables',1),
(81,'2026_04_11_100000_create_bug_report_attachments_table',1),
(82,'2026_04_11_120000_bug_report_unread_tracking',1),
(83,'2026_04_11_130000_add_bug_inbox_last_seen_bug_id_to_user',1),
(84,'2026_04_12_000001_extend_chat_messages',1),
(85,'2026_04_12_000002_add_is_pinned_to_chat_thread_members',1),
(86,'2026_04_12_100000_add_campus_id_to_subject_table',1),
(87,'2026_04_12_200000_remap_orphaned_subject_ids',1),
(88,'2026_04_12_210000_add_subject_id_to_class_session',1),
(89,'2026_04_13_300000_add_closed_reason_to_student_class',1),
(90,'2026_04_13_400000_merge_excused_into_leave',1),
(91,'2026_04_14_000001_add_shipai_dunhua_campuses',1),
(92,'2026_04_14_100000_add_is_contract_exception_to_class_session',1),
(93,'2026_04_14_200000_add_luzhou_campus',1),
(94,'2026_04_14_210000_add_datong_campus',1),
(95,'2026_04_14_300000_add_perf_indexes_learning_records',1),
(96,'2026_04_14_400000_create_payroll_tables',1),
(97,'2026_04_15_100000_create_payroll_branch_rules',1),
(98,'2026_04_15_200000_create_payroll_teacher_branch_rules',1),
(99,'2026_04_15_300000_add_package_fields_to_student_class',1),
(100,'2026_04_15_300001_create_package_session_ledger',1),
(101,'2026_04_15_400000_add_perf_indexes_bug_reports',1),
(102,'2026_04_15_500000_create_payment_reports_table',1),
(103,'2026_04_16_100000_add_core_perf_indexes',1),
(104,'2026_04_16_175714_add_next_week_test_scope_to_learning_records_table',1),
(105,'2026_04_16_200000_create_student_line_bindings_table',1),
(106,'2026_04_16_210000_add_void_fields_to_payment_reports_table',1),
(107,'2026_04_17_100000_add_session_charge_to_class_session',1),
(108,'2026_04_17_200000_create_schedule_discrepancies_table',1),
(109,'2026_04_17_200001_add_staff_line_group_id_to_campus',1),
(110,'2026_04_17_300000_add_billing_mode_to_course_packages',1),
(111,'2026_04_17_400000_drop_monthly_fee_from_course_packages',1),
(112,'2026_04_17_500000_backfill_session_charge_for_session_mode',1),
(113,'2026_04_19_100000_add_corrected_time_range_to_schedule_discrepancies',1),
(114,'2026_04_19_200000_add_backfill_note_to_payment_reports_table',1),
(115,'2026_04_21_000001_add_schedules_composite_index',1),
(116,'2026_04_21_000002_normalize_schedules_start_time',1),
(117,'2026_04_21_202540_backfill_paid_status_where_paydate_not_null',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_session_ledger`
--

DROP TABLE IF EXISTS `package_session_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `package_session_ledger` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `package_id` bigint(20) unsigned NOT NULL,
  `student_class_id` bigint(20) unsigned NOT NULL,
  `class_session_id` bigint(20) unsigned DEFAULT NULL,
  `delta` tinyint(4) NOT NULL COMMENT '+1 reverse, -1 deduct',
  `reason` varchar(64) NOT NULL DEFAULT 'attendance',
  `recorded_by` bigint(20) unsigned DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `request_id` varchar(64) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pkg_session_reason` (`package_id`,`class_session_id`,`reason`),
  KEY `idx_psl_package` (`package_id`),
  KEY `idx_psl_sc` (`student_class_id`),
  KEY `idx_psl_cs` (`class_session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_session_ledger`
--

LOCK TABLES `package_session_ledger` WRITE;
/*!40000 ALTER TABLE `package_session_ledger` DISABLE KEYS */;
/*!40000 ALTER TABLE `package_session_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_requests`
--

DROP TABLE IF EXISTS `password_reset_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `account_input` varchar(128) NOT NULL,
  `role_input` varchar(32) DEFAULT NULL,
  `status` varchar(32) NOT NULL DEFAULT 'pending',
  `requested_ip` varchar(64) DEFAULT NULL,
  `request_note` varchar(255) DEFAULT NULL,
  `handled_by` int(10) unsigned DEFAULT NULL,
  `handled_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pwd_reset_req_lookup_idx` (`account_input`,`role_input`,`status`),
  KEY `password_reset_requests_user_id_index` (`user_id`),
  KEY `password_reset_requests_status_index` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_requests`
--

LOCK TABLES `password_reset_requests` WRITE;
/*!40000 ALTER TABLE `password_reset_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_reports`
--

DROP TABLE IF EXISTS `payment_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `StudentID` bigint(20) unsigned NOT NULL,
  `StudentClassID` bigint(20) unsigned NOT NULL,
  `InvoiceID` bigint(20) unsigned DEFAULT NULL,
  `reported_by_name` varchar(64) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` varchar(16) NOT NULL DEFAULT 'transfer',
  `reported_amount` decimal(10,2) NOT NULL,
  `account_last5` varchar(5) DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'pending',
  `confirmed_by` bigint(20) unsigned DEFAULT NULL,
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `rejection_note` text DEFAULT NULL,
  `voided_by` bigint(20) unsigned DEFAULT NULL,
  `voided_at` timestamp NULL DEFAULT NULL,
  `void_reason` varchar(500) DEFAULT NULL,
  `backfill_note` varchar(500) DEFAULT NULL,
  `report_token_hash` varchar(128) NOT NULL,
  `token_expires_at` timestamp NOT NULL,
  `payment_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_reports_studentid_index` (`StudentID`),
  KEY `payment_reports_studentclassid_index` (`StudentClassID`),
  KEY `payment_reports_status_index` (`status`),
  KEY `payment_reports_report_token_hash_index` (`report_token_hash`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_reports`
--

LOCK TABLES `payment_reports` WRITE;
/*!40000 ALTER TABLE `payment_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_audit_log`
--

DROP TABLE IF EXISTS `payroll_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_audit_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(10) unsigned NOT NULL,
  `month` char(7) NOT NULL,
  `action` enum('lock','reopen','reviewed','rule_update','teacher_rule_update','teacher_rule_revert') NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_audit_log`
--

LOCK TABLES `payroll_audit_log` WRITE;
/*!40000 ALTER TABLE `payroll_audit_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_branch_rules`
--

DROP TABLE IF EXISTS `payroll_branch_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_branch_rules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(10) unsigned NOT NULL,
  `base_rates` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`base_rates`)),
  `headcount_bonus` int(10) unsigned NOT NULL DEFAULT 50,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `payroll_branch_rules_branch_id_id_index` (`branch_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_branch_rules`
--

LOCK TABLES `payroll_branch_rules` WRITE;
/*!40000 ALTER TABLE `payroll_branch_rules` DISABLE KEYS */;
INSERT INTO `payroll_branch_rules` VALUES
(1,1,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(2,16,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(3,10,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(4,9,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(5,14,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(6,5,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(7,15,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(8,2,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(9,12,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(10,13,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(11,8,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(12,6,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(13,4,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(14,3,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(15,11,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05'),
(16,7,'{\"high\":400,\"junior\":350,\"elementary\":300,\"tutoring\":200}',50,NULL,'2026-04-21 16:42:05');
/*!40000 ALTER TABLE `payroll_branch_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_month_status`
--

DROP TABLE IF EXISTS `payroll_month_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_month_status` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `branch_id` int(10) unsigned NOT NULL,
  `month` char(7) NOT NULL,
  `status` enum('draft','reviewed','locked') NOT NULL DEFAULT 'draft',
  `locked_by` int(10) unsigned DEFAULT NULL,
  `locked_at` datetime DEFAULT NULL,
  `rule_version_id` bigint(20) unsigned DEFAULT NULL,
  `teacher_rule_snapshots` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`teacher_rule_snapshots`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payroll_month_status_branch_id_month_unique` (`branch_id`,`month`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_month_status`
--

LOCK TABLES `payroll_month_status` WRITE;
/*!40000 ALTER TABLE `payroll_month_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_month_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payroll_teacher_branch_rules`
--

DROP TABLE IF EXISTS `payroll_teacher_branch_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_teacher_branch_rules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `teacher_user_id` int(10) unsigned NOT NULL,
  `branch_id` int(10) unsigned NOT NULL,
  `base_rates` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`base_rates`)),
  `headcount_bonus` int(10) unsigned NOT NULL DEFAULT 50,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ptbr_branch_teacher_id` (`branch_id`,`teacher_user_id`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payroll_teacher_branch_rules`
--

LOCK TABLES `payroll_teacher_branch_rules` WRITE;
/*!40000 ALTER TABLE `payroll_teacher_branch_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_teacher_branch_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rooms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `campus_id` int(10) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `capacity` int(10) unsigned NOT NULL DEFAULT 1,
  `memo` varchar(512) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rooms_campus_id_index` (`campus_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule_discrepancies`
--

DROP TABLE IF EXISTS `schedule_discrepancies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_discrepancies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class_session_id` bigint(20) unsigned DEFAULT NULL,
  `reporter_id` bigint(20) unsigned NOT NULL,
  `branch_id` int(10) unsigned NOT NULL,
  `discrepancy_type` enum('student_no_show','wrong_student_list','wrong_time','class_cancelled','missing_session','other') NOT NULL,
  `session_date` date DEFAULT NULL,
  `subject` varchar(64) DEFAULT NULL,
  `student_name` varchar(64) DEFAULT NULL,
  `time_range` varchar(32) DEFAULT NULL,
  `corrected_time_range` varchar(32) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `status` enum('pending','acknowledged','resolved','withdrawn') NOT NULL DEFAULT 'pending',
  `acknowledged_by` bigint(20) unsigned DEFAULT NULL,
  `acknowledged_at` timestamp NULL DEFAULT NULL,
  `resolved_by` bigint(20) unsigned DEFAULT NULL,
  `resolved_at` timestamp NULL DEFAULT NULL,
  `resolution_note` varchar(500) DEFAULT NULL,
  `withdrawn_at` timestamp NULL DEFAULT NULL,
  `archived_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sd_branch_status_created_idx` (`branch_id`,`status`,`created_at`),
  KEY `sd_reporter_created_idx` (`reporter_id`,`created_at`),
  KEY `sd_session_status_idx` (`class_session_id`,`status`),
  KEY `sd_archived_idx` (`archived_at`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule_discrepancies`
--

LOCK TABLES `schedule_discrepancies` WRITE;
/*!40000 ALTER TABLE `schedule_discrepancies` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule_discrepancies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedules`
--

DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `day_of_week` int(11) NOT NULL,
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  `duration_hours` decimal(5,2) DEFAULT NULL,
  `class_type` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'scheduled',
  `type` varchar(255) NOT NULL DEFAULT 'normal',
  `deduction` int(11) NOT NULL DEFAULT 1,
  `branch_id` int(11) NOT NULL,
  `schedule_date` date DEFAULT NULL,
  `student_course_id` int(11) DEFAULT NULL,
  `original_schedule_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sched_course_date_time_status` (`student_course_id`,`schedule_date`,`start_time`,`status`,`original_schedule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules`
--

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_charge_backfill_log`
--

DROP TABLE IF EXISTS `session_charge_backfill_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session_charge_backfill_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class_session_id` bigint(20) unsigned NOT NULL,
  `student_class_id` bigint(20) unsigned NOT NULL,
  `old_session_charge` int(11) DEFAULT NULL,
  `new_session_charge` int(11) DEFAULT NULL,
  `charge_delta` int(11) NOT NULL DEFAULT 0,
  `reason` varchar(64) NOT NULL DEFAULT 'session_mode_fixed_rate_backfill',
  `applied_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `session_charge_backfill_log_class_session_id_index` (`class_session_id`),
  KEY `session_charge_backfill_log_student_class_id_index` (`student_class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_charge_backfill_log`
--

LOCK TABLES `session_charge_backfill_log` WRITE;
/*!40000 ALTER TABLE `session_charge_backfill_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `session_charge_backfill_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session_deduction_ledger`
--

DROP TABLE IF EXISTS `session_deduction_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session_deduction_ledger` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_class_id` bigint(20) unsigned NOT NULL,
  `class_session_id` bigint(20) unsigned DEFAULT NULL,
  `event_type` varchar(16) NOT NULL,
  `source` varchar(32) NOT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ledger_unique_check` (`student_class_id`,`class_session_id`,`event_type`),
  KEY `session_deduction_ledger_student_class_id_index` (`student_class_id`),
  KEY `session_deduction_ledger_class_session_id_index` (`class_session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_deduction_ledger`
--

LOCK TABLES `session_deduction_ledger` WRITE;
/*!40000 ALTER TABLE `session_deduction_ledger` DISABLE KEYS */;
/*!40000 ALTER TABLE `session_deduction_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_line_bindings`
--

DROP TABLE IF EXISTS `student_line_bindings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_line_bindings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint(20) unsigned NOT NULL,
  `line_user_id` varchar(64) NOT NULL,
  `campus_id` bigint(20) unsigned DEFAULT NULL,
  `bound_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slb_student_line_unique` (`student_id`,`line_user_id`),
  KEY `slb_line_user_id_idx` (`line_user_id`),
  KEY `slb_campus_id_idx` (`campus_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_line_bindings`
--

LOCK TABLES `student_line_bindings` WRITE;
/*!40000 ALTER TABLE `student_line_bindings` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_line_bindings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_monthly_stats`
--

DROP TABLE IF EXISTS `teacher_monthly_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher_monthly_stats` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `TeacherID` bigint(20) unsigned NOT NULL,
  `YearMonth` varchar(7) NOT NULL,
  `SessionCount` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `teacher_monthly_stats_teacherid_yearmonth_unique` (`TeacherID`,`YearMonth`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_monthly_stats`
--

LOCK TABLES `teacher_monthly_stats` WRITE;
/*!40000 ALTER TABLE `teacher_monthly_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `teacher_monthly_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_subject_levels`
--

DROP TABLE IF EXISTS `teacher_subject_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher_subject_levels` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `teacher_id` bigint(20) unsigned NOT NULL,
  `subject_id` int(10) unsigned NOT NULL,
  `level` enum('elementary','junior','high') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tsl_unique` (`teacher_id`,`subject_id`,`level`),
  KEY `teacher_subject_levels_teacher_id_index` (`teacher_id`),
  KEY `teacher_subject_levels_subject_id_index` (`subject_id`),
  KEY `teacher_subject_levels_level_index` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_subject_levels`
--

LOCK TABLES `teacher_subject_levels` WRITE;
/*!40000 ALTER TABLE `teacher_subject_levels` DISABLE KEYS */;
/*!40000 ALTER TABLE `teacher_subject_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_subjects`
--

DROP TABLE IF EXISTS `teacher_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher_subjects` (
  `teacher_id` bigint(20) unsigned NOT NULL,
  `subject_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`teacher_id`,`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_subjects`
--

LOCK TABLES `teacher_subjects` WRITE;
/*!40000 ALTER TABLE `teacher_subjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `teacher_subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_login_activities`
--

DROP TABLE IF EXISTS `user_login_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_login_activities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `login_at` timestamp NULL DEFAULT NULL,
  `ip_address` varchar(64) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `device_label` varchar(120) DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 1,
  `auth_token_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_login_activities_user_id_login_at_index` (`user_id`,`login_at`),
  KEY `user_login_activities_auth_token_id_index` (`auth_token_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_login_activities`
--

LOCK TABLES `user_login_activities` WRITE;
/*!40000 ALTER TABLE `user_login_activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_login_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_notification_preferences`
--

DROP TABLE IF EXISTS `user_notification_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_notification_preferences` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `in_app_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `email_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `line_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `quiet_hours_start` varchar(5) DEFAULT NULL,
  `quiet_hours_end` varchar(5) DEFAULT NULL,
  `event_tuition` tinyint(1) NOT NULL DEFAULT 1,
  `event_learning_review` tinyint(1) NOT NULL DEFAULT 1,
  `event_attendance` tinyint(1) NOT NULL DEFAULT 1,
  `event_system` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_notification_preferences_user_id_unique` (`user_id`),
  KEY `user_notification_preferences_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_notification_preferences`
--

LOCK TABLES `user_notification_preferences` WRITE;
/*!40000 ALTER TABLE `user_notification_preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_notification_preferences` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-22  0:48:12
